##Tech. Questions

Q-1) I spent about 3-4 hours making this technical case. If I had more time, maybe I would try to do it more structurally for readability and maintainability of the code.
Q-2) I used VS Code in the frontend, and I developed it in VisualStudio in the backend. I'm used to them because I've developed it here before, these tools are comfortable for me.
For Frontend; I created an Angular project and used the MaterialUI library to use ready-made design of components.
For the backend; I created a .NetCore API as a project and implemented an endpoint. After reading the json file that I used as a datasource, I used the Newtonsoft.json package to convert it to the model.
Q-3) CI/CD is available for deployment. In order to deploy to any selected cloud, thanks to the file we wrote with Terraform, we can instantly set up and deploy the environment I want, regardless of the cloud.
Q-4) I can protect sensitive data with encryption methods.
Q-5) I solve the performance problem in production with timer logs that I will add to the service, and I examine the logs and detect and fix the performance problem. In the last incident I had about this, the customer claimed that the service I implemented was slow, but when we examined the logs, it was determined that the performance problem was from the network layer.

##How to run

For BE side;

- You can open BE solution on your VisualStudio.
- Then you can run it.

For FE side; 

 Application:
- npm install
- npm run start

 Tests:
- npm run test
