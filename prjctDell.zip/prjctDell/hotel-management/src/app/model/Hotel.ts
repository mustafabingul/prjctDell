export interface HotelInformation {
    name: string
    description: string
    location: string
    rate: number
  }