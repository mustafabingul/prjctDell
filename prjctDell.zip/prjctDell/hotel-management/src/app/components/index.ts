import { SearchBarComponent } from './searchbar/SearchBar.component'
import { TableComponent } from './table/table.component'

export default [SearchBarComponent, TableComponent]
