﻿namespace HotelManagement.Model
{
    public class HotelInfo
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public int Rate { get; set; }
    }
}
